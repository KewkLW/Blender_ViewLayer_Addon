bl_info = {
    "name": "View Layer List",
    "author": "Kewk",
    "version": (1, 0),
    "blender": (3, 6, 0),
    "location": "View3D > Sidebar > View Layer List",
    "category": "3D View",
}

import bpy

class ViewLayerListPanel(bpy.types.Panel):
    bl_label = "View Layer List"
    bl_idname = "OBJECT_PT_view_layer_list"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Tool'
    
    def draw(self, context):
        layout = self.layout
        scene = context.scene

        for vl in scene.view_layers:
            row = layout.row()
            row.label(text=vl.name)
            row.prop(vl, "use", text="")

def register():
    bpy.utils.register_class(ViewLayerListPanel)

def unregister():
    bpy.utils.unregister_class(ViewLayerListPanel)

if __name__ == "__main__":
    register()
